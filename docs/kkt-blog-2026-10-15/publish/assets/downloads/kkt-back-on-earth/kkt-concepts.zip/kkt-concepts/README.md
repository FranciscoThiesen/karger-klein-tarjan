# Checked explanatory figures

Run `python3 scripts/draw_concepts.py` with matplotlib 3.9.4. The script creates `assets/` with three desktop/mobile SVG and retina PNG pairs and `concept-checks.json`. It independently checks the graph examples before drawing. No native solver, benchmark measurement, network, or browser is used. These are deliberate constructions, not representative random samples or benchmark fixtures.

The ID-budget schematic describes the January 2026 bitmap regression, not the 2022 implementation. The sample/filter witness preserves the exact MST while discarding 18 of 28 edges. The weight-order pair deliberately makes a cheap star in one permutation; the timing studies use random shuffled twins.
